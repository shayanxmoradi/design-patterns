package FactoryMethod;

public class WhatsappMessage {
    private String message;
    private String phoneNumber;
    public WhatsappMessage(String message, String phoneNumber) {
        this.message = message;
        this.phoneNumber = phoneNumber;
    }
}

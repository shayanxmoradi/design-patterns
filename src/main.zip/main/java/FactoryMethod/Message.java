package FactoryMethod;

public abstract class Message  {
    private  String message;

}

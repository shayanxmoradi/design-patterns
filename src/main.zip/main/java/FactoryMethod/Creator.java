package FactoryMethod;

public class Creator {
    public static void main(String[] args) {

    }



}
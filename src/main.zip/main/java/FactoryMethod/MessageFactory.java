package FactoryMethod;

public abstract class MessageFactory {
    public abstract Message createMessage(String message);
}

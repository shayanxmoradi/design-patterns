package FactoryMethod;

public class TelegramMessage {
    private String text;
    private String telegramId;
    public TelegramMessage(String text, String telegramId) {
        this.text = text;
        this.telegramId = telegramId;

    }
}
